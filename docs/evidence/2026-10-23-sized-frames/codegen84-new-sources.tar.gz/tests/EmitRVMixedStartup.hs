-- A deliberately legacy-only Core value keeps startup coexistence covered
-- while the last fallback users are retired. Source-level frame probes no
-- longer force a fallback after sized reservation was implemented.
import Codegen
import Codegen.IR (Width(..))
import Codegen.Policy
import Codegen.Target.RV (RVHart(..))
import Codegen.Target.Common (noTune)
import FPRISC (Core(..))
import qualified Data.Map.Strict as M
import qualified Data.Set as S
import Control.Monad (unless)
import System.Environment (getArgs)

main :: IO ()
main = do
  [bits,path] <- getArgs
  let width = if bits == "32" then W32 else W64
      mode = NativeMode PerFunction StrictOff "mixed-startup" (Just (DirectRV width HartTp)) False noTune False True
      target = (if bits == "32" then rv32 else rv64)
        {tgtNative=Just mode,tgtPolicy=m2Policy {polProfile=if bits=="32" then Rv32 else HostedBase}}
      prog = M.fromList [("opaque",([],CVar "hostValue")),("probe",(["x"],CVar "x"))]
      out = emitProgramWith target True False [] M.empty S.empty S.empty prog
  unless (emNativeNames out == ["probe"] && map fst (emFallbacks out) == ["opaque"])
    (error "mixed startup probe did not retain both generators")
  writeFile path (emAsm out ++ unlines (emNative out))
